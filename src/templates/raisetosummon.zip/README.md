# Raise Funds to Summon Nick Johnson to your Hackathon

This is an example of a real world DApp which [The Decentralized Camp - Stockholm](https://meetup.com/decentralized-camp) used to Summon the very knowledgable and generous Nick Johnson to Stockholm for the annual hackathon.

## HOW TO

In 'Configure' section of Contract you can configure constructor parameters by your needs. After deploying the Contract - receiver of the funds has to set minimum amount required.