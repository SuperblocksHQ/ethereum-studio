# SafeMath from OpenZeppelin example

Math operations with safety checks that throw on error.
