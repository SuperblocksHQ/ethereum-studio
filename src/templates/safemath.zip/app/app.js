// The object 'Contracts' will be injected here, which contains all data for all contracts, keyed on contract name:
// Contracts['TestContract'] = {
//  abi: [],
//  address: "0x..",
//  endpoint: "http://...."
// }

function TestContract(Contract) {
    this.web3 = null;
    this.instance = null;
    this.Contract = Contract;
}

TestContract.prototype.init = function() {
    // We create a new Web3 instance using either the Metamask provider
    // or an independent provider created towards the endpoint configured for the contract.
    this.web3 = new Web3(
        (window.web3 && window.web3.currentProvider) ||
        new Web3.providers.HttpProvider(this.Contract.endpoint));

    // Create the contract interface using the ABI provided in the configuration.
    var contract_interface = this.web3.eth.contract(this.Contract.abi);

    // Create the contract instance for the specific address provided in the configuration.
    this.instance = contract_interface.at(this.Contract.address);
}

// Addition method, calls Contract's safeAdd and appends it into HTML
TestContract.prototype.updateAdd = function() {
    var firstValue = $("#input-add-first").val();
    var secondValue = $("#input-add-second").val();

    // Disallow negative numbers
    if(firstValue >= 0 && secondValue >= 0) {
        this.instance.safeAdd(firstValue, secondValue, function (error, result) {
            if(error) {
                console.log(error);
            }
            else {
                $("#status").html("");
                $("#add-result").html(result.toNumber());
            }
        });
    }
    else {
        $("#status").html("Negative values not allowed");
        $("#add-result").html("0");
    }
}

// Substraction method, calls Contract's safeSub and appends it into HTML
TestContract.prototype.updateSub = function() {
    var firstValue = $("#input-sub-first").val();
    var secondValue = $("#input-sub-second").val();

    // Disallow negative numbers
    if(firstValue >= 0 && secondValue >= 0) {
        this.instance.safeSub(firstValue, secondValue, function (error, result) {
            if(error) {
                console.log(error);
            }
            else {
                $("#status").html("");
                $("#sub-result").html(result.toNumber());
            }
        });
    }
    else {
        $("#status").html("Negative values not allowed");
        $("#sub-result").html("0");
    }
}

// Division method, calls Contract's safeDiv and appends it into HTML
TestContract.prototype.updateDiv = function() {
    var firstValue = $("#input-div-first").val();
    var secondValue = $("#input-div-second").val();

    // Disallow negative numbers
    if(firstValue >= 0 && secondValue >= 0) {
        this.instance.safeDiv(firstValue, secondValue, function (error, result) {
            if(error) {
                console.log(error);
            }
            else {
                $("#status").html("");
                $("#div-result").html(result.toNumber());
            }
        });
    }
    else {
        $("#status").html("Negative values not allowed");
        $("#div-result").html("0");
    }
}

// Multiplication method, calls Contract's safeMul and appends it into HTML
TestContract.prototype.updateMul = function() {
    var firstValue = $("#input-mul-first").val();
    var secondValue = $("#input-mul-second").val();

    // Disallow negative numbers
    if(firstValue >= 0 && secondValue >= 0) {
        this.instance.safeMul(firstValue, secondValue, function (error, result) {
            if(error) {
                console.log(error);
            }
            else {
                $("#status").html("");
                $("#mul-result").html(result.toNumber());
            }
        });
    }
    else {
        $("#status").html("Negative values not allowed");
        $("#mul-result").html("0");
    }
}

// Binds all inputs to update data onChange
TestContract.prototype.bindInputs = function() {
    var that = this;
    var timeout = null; // Set timeout to every input so it doesn't fire too often

    $(document).on("change textInput input", "#input-add-first, #input-add-second", function() {
        clearTimeout(timeout);
        timeout = setTimeout(function() {
            that.updateAdd();
        }, 250);  
    })

    $(document).on("change textInput input", "#input-sub-first, #input-sub-second", function() {
        clearTimeout(timeout);
        timeout = setTimeout(function() {
            that.updateSub();
        }, 250);  
    })

    $(document).on("change textInput input", "#input-div-first, #input-div-second", function() {
        clearTimeout(timeout);
        timeout = setTimeout(function() {
            that.updateDiv();
        }, 250);  
    })

    $(document).on("change textInput input", "#input-mul-first, #input-mul-second", function() {
        clearTimeout(timeout);
        timeout = setTimeout(function() {
            that.updateMul();
        }, 250);  
    })
}

TestContract.prototype.onReady = function() {
    this.init();
    this.bindInputs();
}

var testContract = new TestContract(Contracts['TestContract']);

$(document).ready(function() {
    testContract.onReady();
});