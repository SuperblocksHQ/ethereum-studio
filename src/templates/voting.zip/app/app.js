// The object 'Contracts' will be injected here, which contains all data for all contracts, keyed on contract name:
// Contracts['Vote'] = {
//  abi: [],
//  address: "0x..",
//  endpoint: "http://...."
// }

function Vote(Contract) {
    this.web3 = null;
    this.instance = null;
    this.Contract = Contract;
}

Vote.prototype.initContract = function() {
    // We create a new Web3 instance using either the Metamask provider
    // or an independent provider created towards the endpoint configured for the contract.
    this.web3 = new Web3(
        (window.web3 && window.web3.currentProvider) ||
        new Web3.providers.HttpProvider(this.Contract.endpoint));

    // Create the contract interface using the ABI provided in the configuration.
    var contract_interface = this.web3.eth.contract(this.Contract.abi);
    

    // Create the contract instance for the specific address provided in the configuration.
    this.instance = contract_interface.at(this.Contract.address);
};

// Returns count of Candidates from contract
Vote.prototype.getCount = function(cb) {
    this.instance.getCandidatesCount(function (error, result) {
        cb(error, result);
    });
}

// Returns Candidate by index from contract
Vote.prototype.getCandidate = function(index, cb) {
    this.instance.getCandidate(index, function (error, result) {
        cb(error, result);
    });
}

// Checks if sender is owner of the contract
Vote.prototype.isOwnerOfContract = function(cb) {
    this.instance.owner(function (error, result) {
        // Compare user's address with owner of the Contract
        result = result == window.web3.eth.accounts[0];
        cb(error, result);
    });
}

// Increases voteCount of Candidate found by index
Vote.prototype.addVote = function(index, cb) {
    var that = this;

    if(isNaN(index) || index < 0) {
        alert("Could not find Candidate with this index... Try it again.");
        return;
    }

    if (typeof window.web3 !== 'undefined' && window.web3.currentProvider) {
 
        // Gas and gasPrice should be remove for non browser networks
        this.instance.voteFor(index, { from: window.web3.eth.accounts[0], gas: 50000, gasPrice: 100000, gasLimit: 100000 },
            function(error, txHash) {
                $("#status").html('Voting in progress...');

                if (error) {
                    console.error(error);
                    $("#status").html("Vote canceled, try it again.");
                    return;
                } else {
                    that.waitForReceipt(txHash, function(receipt) {
                        if(receipt.status) {
                            var updatedVotes = parseInt($("#candidate-"+index+" .votes").text(), 10) + 1;
                            $("#candidate-"+index+" .votes").html(updatedVotes);
                            $("#status").html("Vote successful");
                        }
                        else {
                            $("#status").html("Vote not successful. Please try it again.");
                        }
                    });
                }
            }
        );
    } else {
        $("#status").html("You must have Metamask installed...");
    }  
}

// Edit Candidate found by index
Vote.prototype.editCandidate = function(index, newName, cb) {
    var that = this;

    if(isNaN(index) || index < 0) {
        alert("Could not find Candidate with this index... Try it again.");
        return;
    }

    if (typeof window.web3 !== 'undefined' && window.web3.currentProvider) {

        this.instance.updateCandidate(index, newName, { from: window.web3.eth.accounts[0], gas: 100000, gasPrice: 100000, gasLimit: 100000 },
            function(error, txHash) {
                if(error) {
                    console.error(error);
                    $("#status").html("Editing canceled, try it again.");
                    return;
                } else {
                    that.waitForReceipt(txHash, function(receipt) {
                        if(receipt.status) {
                            $("#status").html("Candidate edited successfuly");
                            $("#candidate-"+index+" .name").html(newName);
                        }
                        else {
                            $("#status").html("Editin didn't go well. Please try it again.");
                        }
                    });
                }
            }
        );
    }
}

// Add new Candidate
Vote.prototype.addCandidate = function(newName, cb) {
    var that = this;

    if (typeof window.web3 !== 'undefined' && window.web3.currentProvider) {

        this.instance.addCandidate(newName, { from: window.web3.eth.accounts[0], gas: 100000, gasPrice: 100000, gasLimit: 100000 },
            function(error, txHash) {
                if(error) {
                    console.error(error);
                    $("#status").html("Transaction canceled, try it again.");
                    return;
                } else {
                    that.waitForReceipt(txHash, function(receipt) {
                        if(receipt.status) {
                            that.getCount(function (error, result) {
                                if(error) {
                                    console.log(error);
                                    $(".error").show();
                                    return;
                                }

                                var indexNew = result.toNumber() - 1;
                                that.renderCandidate(indexNew);
                                $("#status").html("Candidate added successfuly");

                            });
                        }
                        else {
                            $("#status").html("Adding didn't go well. Please try it again.");
                        }
                    });
                }
            }
        );
    }
}

// Remove Candidate found by index
Vote.prototype.removeCandidate = function(index, cb) {
    var that = this;

    if(isNaN(index) || index < 0) {
        alert("Could not find Candidate with this index... Try it again.");
        return;
    }

    if (typeof window.web3 !== 'undefined' && window.web3.currentProvider) {
 
        // Gas and gasPrice should be remove for non browser networks
        this.instance.removeCandidate(index, { from: window.web3.eth.accounts[0], gas: 100000, gasPrice: 100000, gasLimit: 100000 },
            function(error, txHash) {
                $("#status").html('Removing candidate...');

                if (error) {
                    console.error(error);
                    $("#status").html("Removing canceled, try it again.");
                    return;
                } else {
                    that.waitForReceipt(txHash, function(receipt) {
                        if(receipt.status) {
                            $('#candidate-'+index).remove();
                            $("#status").html("Removing successful");
                        }
                        else {
                            $("#status").html("Removing didn't go well. Please try it again.");
                        }
                    });
                }
            }
        );
    } else {
        $("#status").html("You must have Metamask installed and be owner of the contract.");
    }  
}

// Waits for receipt from transaction
Vote.prototype.waitForReceipt = function(hash, cb) {
    var that = this;

    // Checks for transaction receipt
    this.web3.eth.getTransactionReceipt(hash, function(err, receipt) {
        if (err) {
            error(err);
        }
        if (receipt !== null) {
            // Transaction went through
            if (cb) {
                cb(receipt);
            }
        } else {
            // Try again in 2 second
            window.setTimeout(function() {
                that.waitForReceipt(hash, cb);
            }, 2000);
        }
    });
}

// Renders single Candidate by index
Vote.prototype.renderCandidate = function(index) {
    var that = this;

    if (index < 0) {
        console.log("No candidates found...");
        return;
    }

    var isOwner;
    this.isOwnerOfContract(function (error, result) {
        isOwner = result;
    });

    this.getCandidate(index, function (error, result) {
        if (error) {
            console.error("Could not load candidate:", error);
            $('#candidates table').append(
                "<tr><td>Could not load candidate.</td></tr>"
            );
            return;
        }
        else {
            var data = `<tr id='candidate-`+index+`'><td><span class="name">` + result[0] + `</span>`;

                if(isOwner) {
                    data += `
                            <button class="button-remove" id='`+ index +`'>
                                <svg width="14px" aria-hidden="true" data-prefix="far" data-icon="trash-alt" class="svg-inline--fa fa-trash-alt fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M192 188v216c0 6.627-5.373 12-12 12h-24c-6.627 0-12-5.373-12-12V188c0-6.627 5.373-12 12-12h24c6.627 0 12 5.373 12 12zm100-12h-24c-6.627 0-12 5.373-12 12v216c0 6.627 5.373 12 12 12h24c6.627 0 12-5.373 12-12V188c0-6.627-5.373-12-12-12zm132-96c13.255 0 24 10.745 24 24v12c0 6.627-5.373 12-12 12h-20v336c0 26.51-21.49 48-48 48H80c-26.51 0-48-21.49-48-48V128H12c-6.627 0-12-5.373-12-12v-12c0-13.255 10.745-24 24-24h74.411l34.018-56.696A48 48 0 0 1 173.589 0h100.823a48 48 0 0 1 41.16 23.304L349.589 80H424zm-269.611 0h139.223L276.16 50.913A6 6 0 0 0 271.015 48h-94.028a6 6 0 0 0-5.145 2.913L154.389 80zM368 128H80v330a6 6 0 0 0 6 6h276a6 6 0 0 0 6-6V128z"></path></svg>
                            </button>
                            <button class="button-edit" id='`+ index +`'>
                                <svg width="14px" aria-hidden="true" data-prefix="fas" data-icon="pencil-alt" class="svg-inline--fa fa-pencil-alt fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M497.9 142.1l-46.1 46.1c-4.7 4.7-12.3 4.7-17 0l-111-111c-4.7-4.7-4.7-12.3 0-17l46.1-46.1c18.7-18.7 49.1-18.7 67.9 0l60.1 60.1c18.8 18.7 18.8 49.1 0 67.9zM284.2 99.8L21.6 362.4.4 483.9c-2.9 16.4 11.4 30.6 27.8 27.8l121.5-21.3 262.6-262.6c4.7-4.7 4.7-12.3 0-17l-111-111c-4.8-4.7-12.4-4.7-17.1 0zM124.1 339.9c-5.5-5.5-5.5-14.3 0-19.8l154-154c5.5-5.5 14.3-5.5 19.8 0s5.5 14.3 0 19.8l-154 154c-5.5 5.5-14.3 5.5-19.8 0zM88 424h48v36.3l-64.5 11.3-31.1-31.1L51.7 376H88v48z"></path></svg>
                            </button>
                        `;
                }
                data += `</td>`;
                data += `
                    <td class="votes">` + result[1] + `</td>
                    <td><button class="button button-vote" id='`+ index + `'>Vote</button></td>;
                </tr>
            `;
       
            $('#candidates table').append(data);
        }
    });
}


// Renders all Candidates from Contract into table
Vote.prototype.renderCandidates = function() {
    var that = this;
    
    this.getCount(function (error, result) {
        if(error) {
            console.log(error);
            $(".error").show();
            return;
        }

        var candidatesCount = result.toNumber();

        if(candidatesCount == 0) {
            $("#status").html(
                "<h3>No candidates found...</h3>"
            );
        } else {
            for(var i = 0; i < candidatesCount; i++) {
                that.renderCandidate(i);
            }
        }
    });
}

// Binds click event to all buttons
Vote.prototype.bindButtons = function() {
    var that = this;

    $(document).on("click", "button.button-vote", function() {
        var index = $(this).attr("id");
        that.addVote(index);
    });

    $(document).on("click", "button.button-remove", function() {
        var index = $(this).attr("id");
        that.removeCandidate(index);
    });

    $(document).on("click", "button.button-edit", function() {
        var index = $(this).attr("id");
        var newName = prompt("Enter new value");
        that.editCandidate(index, newName);
    });

    $(document).on("click", "button.button-add-new", function() {
        var newName = prompt("Enter name of the Candidate");
        that.addCandidate(newName);
    });
}

Vote.prototype.onReady = function() {
    this.initContract();
    this.renderCandidates();
    this.bindButtons();
};

var vote = new Vote(Contracts['Vote']);

$(document).ready(function() {
    vote.onReady();
});