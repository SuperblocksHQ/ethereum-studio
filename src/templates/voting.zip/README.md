# Voting system project

Simple DApp which you can modify to create your own Voting platform.

# Where to go from here

Check out the tutorials to find our more how to build your dapp.
