# The Censorship Resistant News Feed

The point of this DApp is to provide an `Author` with a censorship proof way of publishing news articles containing a link to IPFS or similar.

## Config
The argument to the contract constructor takes the address of the `Author` having rights to publish articles.

This could be the same account as the one deploying the contract or it could be another account.