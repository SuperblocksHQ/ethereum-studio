// The object 'Contracts' will be injected here, which contains all data for all contracts, keyed on contract name:
// Contracts['NewsFeed'] = {
//  abi: [],
//  address: "0x..",
//  endpoint: "http://...."
// }
function Articles(Contract) {
    this.web3 = null;
    this.instance = null;
    this.Contract = Contract;
}

Articles.prototype.getNumArticles = function(cb) {
    this.instance.numArticles(function (error, result) {
        cb(error, result);
    });
}

Articles.prototype.getArticle = function(index, cb) {
    this.instance.getArticle(index, function (error, result) {
        cb(error, result);
    });
}

Articles.prototype.init = function() {
    // We create a new Web3 instance using either the Metamask provider
    // or an independent provider created towards the endpoint configured for the contract.
    this.web3 = new Web3(
        (window.web3 && window.web3.currentProvider) ||
        new Web3.providers.HttpProvider(this.Contract.endpoint));

    // Create the contract interface using the ABI provided in the configuration.
    var contract_interface = this.web3.eth.contract(this.Contract.abi);

    // Create the contract instance for the specific address provided in the configuration.
    this.instance = contract_interface.at(this.Contract.address);
};

Articles.prototype.renderArticle = function(index) {
    var that = this;
    if (index < 0) {
        return;
    }
    this.getArticle(index, function (error, result) {
        if (error) {
            console.error("Could not load article:", error);
            $('#articles').append(
                "<h3>Could not load article.</h3>"
            );
            return;
        }
        else {
            var data = `
                <div class='article'><h3>` + result[0] + `</h3>
                <a target='_blank' href='` + result[1] + `'>` + result[1] + `</a></div>
            `;
            $('#articles').append(data);
        }
        that.renderArticle(index - 1);
    });
}

Articles.prototype.main = function() {
    var that = this;
    this.getNumArticles(function (error, result) {
        if (error) {
            console.error(error);
            $(".error").show();
            return;
        }
        var nrArticles = result.toNumber();
        
        if (nrArticles == 0) {
            $('#articles').append(
                "<h3>No articles here yet.. Try reloading in a while.</h3>"
            );
        }
        else {
            that.renderArticle(nrArticles - 1);
        }
    });
}

Articles.prototype.onReady = function() {
    this.init();
    this.main();
};

var articles = new Articles(Contracts['NewsFeed']);

$(document).ready(function() {
    articles.onReady();
});
