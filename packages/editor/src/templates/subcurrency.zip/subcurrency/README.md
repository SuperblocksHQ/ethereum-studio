# Introduction to dapps - Creating a subcurrency

This dapp implements the simplest form of a cryptocurrency. Read the accompanying Kauri post for more details.
