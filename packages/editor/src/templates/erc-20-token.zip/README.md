# Token ERC-20

Example DApp which uses ERC-20 standard.


## Where to go from here

Check out the tutorials to find our more how to build your dapp.